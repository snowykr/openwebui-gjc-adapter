/**
 * `gjc auth-broker` — manage the gjc credential vault.
 */
import { Args, Command, Flags, renderCommandHelp } from "@gajae-code/utils/cli";
import {
	AUTH_BROKER_ACTIONS,
	type AuthBrokerAction,
	type AuthBrokerCommandArgs,
	runAuthBrokerCommand,
} from "../cli/auth-broker-cli";
import { initTheme } from "../modes/theme/theme";

export default class AuthBroker extends Command {
	static description = "Manage the gjc auth-broker (credential vault)";

	static args = {
		action: Args.string({
			description: "Sub-command",
			required: false,
			options: [...AUTH_BROKER_ACTIONS],
		}),
		// Second positional: provider id (login/logout) or filesystem path (import).
		source: Args.string({
			description: "OAuth provider id (login/logout) or path (import)",
			required: false,
		}),
	};

	static flags = {
		json: Flags.boolean({ description: "Output JSON" }),
		bind: Flags.string({ description: "Bind address for `serve` (host:port)", char: "b" }),
		regenerate: Flags.boolean({ description: "Regenerate the bearer token" }),
		via: Flags.string({
			description: "SSH user@host for remote login (login --via=user@host)",
		}),
		provider: Flags.string({
			description: "Override provider id for `import` (e.g. when JSON `type` is unrecognized)",
		}),
		"include-disabled": Flags.boolean({
			description: "Import credentials whose JSON has `disabled: true` (import)",
		}),
		"from-local": Flags.boolean({
			description: "migrate source: local SQLite + env vars (required for `migrate`)",
		}),
		"include-env": Flags.boolean({
			description: "Capture env-var API keys for providers not yet on broker (migrate)",
		}),
		"include-oauth": Flags.boolean({
			description: "Also upload OAuth from local SQLite during migrate (default skips them)",
		}),
		"dry-run": Flags.boolean({ description: "Print actions without executing (import / login --via / migrate)" }),
	};

	static examples = [
		"# Boot the broker against the local SQLite store\n  gjc auth-broker serve",
		"# Boot on a non-default port\n  gjc auth-broker serve --bind=127.0.0.1:9000",
		"# Print the bearer token\n  gjc auth-broker token",
		"# Rotate the bearer token\n  gjc auth-broker token --regenerate",
		"# Local login (run on the broker host)\n  gjc auth-broker login anthropic",
		"# Remote login over SSH tunnel\n  gjc auth-broker login anthropic --via=user@broker",
		"# Import a CLIProxyAPI auth dump\n  gjc auth-broker import ~/.cliproxy/auth",
		"# Import a single CLIProxyAPI JSON, overriding the provider mapping\n  gjc auth-broker import ~/.cliproxy/auth/claude-foo.json --provider anthropic",
		"# Preview a migration from local store + env vars to the configured broker\n  gjc auth-broker migrate --from-local --include-env --dry-run",
		"# Apply the migration\n  gjc auth-broker migrate --from-local --include-env",
		"# Health-check the configured remote broker\n  gjc auth-broker status",
	];

	async run(): Promise<void> {
		const { args, flags } = await this.parse(AuthBroker);
		if (!args.action) {
			renderCommandHelp("gjc", "auth-broker", AuthBroker);
			return;
		}
		const action = args.action as AuthBrokerAction;
		const cmd: AuthBrokerCommandArgs = {
			action,
			flags: {
				json: flags.json,
				bind: flags.bind,
				regenerate: flags.regenerate,
				via: flags.via,
				// `login`/`logout` reuse the legacy `provider` slot; `import` keeps `source` separate
				// so `provider` flag (used as an override) is unambiguous.
				provider: action === "import" ? flags.provider : (args.source ?? flags.provider),
				source: args.source,
				includeDisabled: flags["include-disabled"],
				fromLocal: flags["from-local"],
				includeEnv: flags["include-env"],
				includeOauth: flags["include-oauth"],
				dryRun: flags["dry-run"],
			},
		};
		await initTheme();
		await runAuthBrokerCommand(cmd);
	}
}
